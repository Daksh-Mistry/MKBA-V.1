"""Hardware abstraction package."""


